import z3

s = z3.Solver()

out = [0xd4, 0x01, 0x83, 0x7d, 0xa1, 0x00, 0xbb, 0xa3, 0xa5, 0x01, 0xd4, 0x9d, 0xe9, 0x7d, 0xee, 0x1c, 0xa2, 0xf4, 0x51, 0xcd, 0xf8, 0xc5, 0xe6, 0x06, 0xba, 0xf2, 0xdb, 0x73, 0xd1, 0x98]
length = 30 #len(out)

vecs = {}

for iter in range(0, length + 1):
  variables = ""
  for i in range(0, length):
    variables += f"data[{iter}][{i}] "
  vecs[iter] = z3.BitVecs(variables, 8)

for i in range(0, length): #length-1):
  for j in range(0, length):
    if j != i:
      s.add(vecs[i+1][j] == vecs[i][j])
  stmt = vecs[i][i]
  stmt += 0x12
  stmt ^= i
  stmt *= ((1 << (i%32)) + 1)
  tgt = (i * 7) % length
  if tgt == i:
    stmt *= 2
  else:
    stmt += vecs[i][tgt]
  s.add(vecs[i+1][i] == stmt)

for i in range(0, length):
  s.add(vecs[0][i] <= 0x7f)
  s.add(vecs[0][i] >= 0x20)
  s.add(vecs[length][i] == out[i])

while s.check() == z3.sat:
  model = s.model()
  out = ""
  nope = []
  for idx in range(0, length):
    i = vecs[0][idx]
    val = model[i].as_long()
    nope.append(i != val)
    if str(i):
      out += chr(val)
  #print(f"Solution: {[hex(ord(i)) for i in out]}")
  print(f"Solution: {out}")
  #out.encode()}")
  s.add(z3.Or(*nope))
