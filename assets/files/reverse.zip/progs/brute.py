import string
import subprocess

chars = string.printable
inv_chars = {i: idx for idx, i in enumerate(chars) }
current = [chars[0]] * 31 + ["\n"]

while True:
  p = subprocess.Popen('./ez', stdin=subprocess.PIPE, stdout=subprocess.PIPE)
  output = p.communicate(input=''.join(current).encode())[0]
  p.wait()
  if output == b"Correct\n":
    break
  pos = p.returncode
  current[pos] = chars[inv_chars[current[pos]] + 1]
  print(''.join(current[:-1]))
