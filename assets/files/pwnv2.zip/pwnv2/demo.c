#include <stdio.h>
#include <stdint.h>

const char text[] = "say something";
char new_text[32];

void dead() {
  puts("Unreachable code");
}

void bar() {
  char buf[8];
  gets(buf);
  puts("You said: ");
  puts(buf);
}

void foo() {
  for (int i = 0; i < sizeof(text); ++i)
    new_text[i] = text[i];
  puts(new_text);
  bar();
}

int main() {
  system("date");
  foo();
}
